package com.arfian.story.data

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.asLiveData
import com.arfian.story.data.pref.LanguagePreference
import com.arfian.story.data.pref.SessionModel
import com.arfian.story.data.pref.SessionPreference
import com.arfian.story.data.service.api.ApiService
import com.arfian.story.data.service.responses.ErrorResponse
import com.arfian.story.data.service.responses.StoryItem
import com.arfian.story.data.service.responses.StoryResponse
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.HttpException

class StoryRepository private constructor(
    private val sessionPreference: SessionPreference,
    private val languagePreference: LanguagePreference,
    private val apiService: ApiService
) {

    suspend fun setLoginStatus() {
        sessionPreference.login()
    }

    suspend fun saveSession(user: SessionModel) {
        sessionPreference.saveSession(user)
    }

    fun getSession(): LiveData<SessionModel> {
        val sessionLiveData = sessionPreference.getSession().asLiveData()
        return sessionLiveData
    }

    suspend fun logout() {
        sessionPreference.logout()
    }

    suspend fun register(name: String, email: String, password: String): Pair<Boolean, String> {
        return withContext(Dispatchers.IO) {
            try {
                val response = apiService.register(name, email, password).execute()
                val body = response.body()
                if (response.isSuccessful && body != null && !body.error) {
                    val user = SessionModel(email, "", true)
                    saveSession(user)
                    Pair(true, "Congratulation $name, your registration are successful!")
                } else {
                    val message = body?.message ?: response.errorBody()?.string() ?: "Unknown error"
                    Pair(false, message)
                }
            } catch (e: HttpException) {
                val jsonInString = e.response()?.errorBody()?.string()
                val errorBody = Gson().fromJson(jsonInString, ErrorResponse::class.java)
                val errorMessage = errorBody.message
                Pair(false, errorMessage)

            } catch (t: Throwable) {
                Pair(false, t.message ?: "Unknown error")
            }
        }
    }

    suspend fun login(email: String, password: String): Pair<Boolean, String> {
        return withContext(Dispatchers.IO) {
            try {
                val response = apiService.login(email, password).execute()
                val body = response.body()
                if (response.isSuccessful && body != null && !body.error) {
                    val user = SessionModel(body.loginResult.userId, body.loginResult.token, true)
                    saveSession(user)
                    Pair(true, user.token)
                } else {
                    val message = body?.message ?: response.errorBody()?.string() ?: "Unknown error"
                    Pair(false, message)
                }
            } catch (e: HttpException) {
                val jsonInString = e.response()?.errorBody()?.string()
                val errorBody = Gson().fromJson(jsonInString, ErrorResponse::class.java)
                val errorMessage = errorBody.message
                Pair(false, errorMessage)
            } catch (t: Throwable) {
                Pair(false, t.message ?: "Unknown error")
            }
        }
    }

    suspend fun getStories(): List<StoryItem> {
        return withContext(Dispatchers.IO) {
            try {
                val response = apiService.getStories()
                response.listStory
            } catch (e: HttpException) {
                val jsonInString = e.response()?.errorBody()?.string()
                val errorBody = Gson().fromJson(jsonInString, StoryResponse::class.java)
                val errorMessage = errorBody.message
                Log.e("SessionRepository", "HttpException: $errorMessage")
                emptyList()
            } catch (t: Throwable) {
                Log.e("SessionRepository", "Throwable: ${t.message}")
                emptyList()
            }
        }
    }

    suspend fun addStory(
        description: RequestBody,
        photo: MultipartBody.Part,
        lat: RequestBody?,
        lon: RequestBody?
    ): Pair<Boolean, String> {
        return withContext(Dispatchers.IO) {
            try {
                val response = apiService.addStory(description, photo, lat, lon).execute()
                val body = response.body()
                if (response.isSuccessful && body != null && !body.error) {
                    Pair(true, "Story uploaded successfully")
                } else {
                    val message = body?.message ?: response.errorBody()?.string() ?: "Unknown error"
                    Pair(false, message)
                }
            } catch (e: HttpException) {
                val jsonInString = e.response()?.errorBody()?.string()
                val errorBody = Gson().fromJson(jsonInString, ErrorResponse::class.java)
                val errorMessage = errorBody.message
                Pair(false, errorMessage)
            } catch (t: Throwable) {
                Pair(false, t.message ?: "Unknown error")
            }
        }
    }

    fun getSelectedLanguage(): String {
        return languagePreference.selectedLanguage
    }

    fun setSelectedLanguage(langCode: String) {
        languagePreference.selectedLanguage = langCode
    }

    companion object {
        @Volatile
        private var instance: StoryRepository? = null
        fun getInstance(
            sessionPreference: SessionPreference,
            languagePreference: LanguagePreference,
            apiService: ApiService
        ): StoryRepository =
            instance ?: synchronized(this) {
                instance ?: StoryRepository(sessionPreference, languagePreference, apiService)
            }.also { instance = it }
    }
}