package com.arfian.story.view.upload

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.arfian.story.data.StoryRepository
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.InputStream

class AddStoryViewModel(private val repository: StoryRepository) : ViewModel() {
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    fun setLoadingState(isLoading: Boolean) {
        _isLoading.value = isLoading
    }

    suspend fun uploadStory(inputStream: InputStream, description: String,  lat: Float?, lon: Float?): Pair<Boolean, String> {
        val descriptionPart = description.toRequestBody("text/plain".toMediaTypeOrNull())

        inputStream.use {
            val bytes = it.readBytes()
            val requestFile = bytes.toRequestBody("image/*".toMediaTypeOrNull())
            val photoPart = MultipartBody.Part.createFormData("photo", "image.jpg", requestFile)

            val latPart = lat?.toString()?.toRequestBody("text/plain".toMediaTypeOrNull())
            val lonPart = lon?.toString()?.toRequestBody("text/plain".toMediaTypeOrNull())

            return repository.addStory(descriptionPart, photoPart, latPart, lonPart)
        }
    }
}